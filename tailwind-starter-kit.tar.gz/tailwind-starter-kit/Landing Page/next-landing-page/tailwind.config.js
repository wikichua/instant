module.exports = {
  future: {
    removeDeprecatedGapUtilities: true,
    purgeLayersByDefault: true,
  },
  purge: false,
  theme: {
    fontFamily: {
      "display" : ["Noto Sans","sans-serif"],
      "body" : ["Noto Sans","sans-serif"],
    },
    extend: {},
  },
  variants: {},
  plugins: [],
}
